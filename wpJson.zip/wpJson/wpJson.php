<?php
/*
Plugin Name: Simon's JSON API
Version: 1.0
Plugin URI: https://affengriff.net
Description: Allow JSON File Upload to Wordpress
Author: Simon Eisele
Author URI: https://affengriff.net
*/

function cc_mime_types($mimes) {

    $mimes['json'] = 'application/json';
    $mimes['svg'] = 'image/svg+xml';

    return $mimes;
}

add_filter('upload_mimes', 'cc_mime_types');